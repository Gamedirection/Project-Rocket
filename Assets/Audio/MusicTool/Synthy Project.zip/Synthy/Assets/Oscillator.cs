﻿using UnityEngine;
using System;
using System.Collections;

/*****************************************************************
	Notes: http://battleofthebits.org/lyceum/View/2a03+(soundchip)
	NES 2x Pulse Channels:	supports frequencies from 28Hz to 54KHz, 16 volume levels, 3 Dutys: 12.5%, 25%, 50%, 75% (Same as 25%) 
	NES Triangle Channel:	supports frequencies from 27Hz to 56KHz, No volume control (sort of),
	NES Noise:				16 volume levels, 2 modes: Long and short. Long: Pretty much white noise. Short: Less random, tends toward higer frequencies 
	
	NES PCM Channel:		Not even going to try to implement this. Plays sounds using: 
							Mode 1: 1-bit delta encoding (-1 or +1) at 16 preprogrammed sample rates: 4.2kHz to 33.5kHz (Basically different playback speeds)
							Mode 2: Normal PCM by writing in 7-bit values at timed intervals

	Pulse Controls
	Envelope:
		Volume:				If Saw envelope off: Direct volume of pulse wave. Envelope on: Period of envelope. 4-bits (0-15)
		Saw Envelope On:	On: Volume adjusted automatically by internal counter. Off: Volume stays constant
		Length Counter On:	Similar to above, but for how long the sound plays.
		Duty Cycle:			Controls Duty Cycle. 12.5%, 25%, 50%, 75% (same as 25%). 2-bits (0-3)

	Other Controls:
		Period:				Controls period. 11-bits (0-2047)

		Length Counter:		How long a note is played. 5-bits (0-31) (Does nothing if constant volume flag is set)


	Noise Generator Period Chart
	Below is a conversion chart that shows what 4-bit value will represent the 11-bit wavelength to be fed to the channel's programmable timer:
	
	value	octave	scale	CPU clock cycles (11-bit wavelength+1)
	-----	------	-----	--------------------------------------
	0		15		A		002
	1		14		A		004
	2		13		A		008
	3		12		A		010
	4		11		A		020
	5		11		D		030
	6		10		A		040
	7		10		F		050
	8		10		C		065
	9		 9		A		07F
	A		 9		D		0BE
	B		 8		A		0FE
	C		 8		D		17D
	D		 7		A		1FC
	E		 6		A		3F9
	F		 5		A		7F2

	Octave and scale information is provided for the music enthusiast programmer who is more familiar with notes than clock cycles.





*****************************************************************/


public enum WaveForm { Sine, Triangle, NESTriangle, Square, Sawtooth, Noise, NESNoise, LogSaw, Fourier }
public enum SineWaveType { Sine, HalfSine, QuarterSine, AbsSine, AlternatingSine, CamelSine }
public class Oscillator : MonoBehaviour {

	public float frequency = 440f;	//Frequency in Hz of tone that is played
	private float increment;		//Amount of distance incremented each frame according to frequency
	private float phase;			//Location on the wave
	public static float samplingFrequency = 48000f;	//
	public float samplingFreqencyInstance;

	public float gain = 0.1f;		//Actual volume of oscillator
	public float volume = 0.1f;
	private const float PI2 = Mathf.PI * 2;

	public bool playSoundFromInput = true;
	public bool playAScale = true;
	public float[] frequencies;
	public int currentFreq;
	
	public WaveForm waveForm = WaveForm.Sine;

	public bool reverseSawtooth = false;

	public int nesTriangleStep = 40;

	public float squareWaveScale = 1f;
	[Range(0f, 1f)]
	public float userPulseWidth = 0.5f;

	//If this goes beyond the size of the gain and a square wave is used, it says stuck in at negative gain = no sound.
	public float PulseWidth {
		get { return userPulseWidth; }//return Mathf.Lerp(0f, 1f, 1f - userPulseWidth); }
	}
		
	private static readonly System.Random random = new System.Random();
	private static readonly object syncLock = new object();

	//public bool nesNoiseEveryOtherCycle = true;
	//private bool nesNoiseOddCycle = true;
	public ushort nesNoiseRegister = 0x0001;//0xFFFF;
	public bool nesNoiseMode = true;
	public float nesNoiseCounter = 0;
	public int nesNoisePeriod = 254;
	public float nesPhaseCheck = 0.99f;
	public float nesNoiseScale = 1f;
	private int nesShiftFlag = 0;
	private bool nesNoiseGotTone = false;
	private bool nesFeedbackBit = false;
	public int nesNoisePresetPitchIndex = 0;
	private bool nesNoiseGotSampleForThisPeriod = false;
	public int[] nesNoisePeriods = { 4, 8, 16, 32, 64, 96, 128, 160, 202, 254, 380, 508, 762, 1016, 2034, 4068 };   //https://wiki.nesdev.com/w/index.php/APU_Noise
	public int[] nesNoisePeriodsAdjusted;
	private int nesNoiseWaitIncrements = 0;
	private int nesNoiseWaitCount = 0;

	private int nesTriangleTimer = 0;
	public int nesTrianglePeriod = 0;
	private int nesTriangleDutyIndex = 0;
	private int[] nesTriangleTable = {
	15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,
	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};

	public float noiseMaxAmp = 1f;
	public bool noiseSquarify = false;
	//public float exTone = 1f;
	public float whitenoisePeriod = 0;
	public float whitenoisePeriodCounter = 0;
	private float savedWhiteNoise;

	public SineWaveType sineType = SineWaveType.Sine;
	public int logsawVoice = 15;

	public Envelope volumeEnvelope;
	public Envelope pitchEnvelope;

	public bool[] testNoiseReg = new bool[16];

	//Additive Synth - Fourier
	public int iterations = 1;
	public float nextHarmonic = 1;

	//public double prevAudioTime = 0;
	//public double audioCumulativeAvg = 0;
	//public long audioReadCount = 0;

	void Awake() {
		//volumeEnvelope = GetComponent<Envelope>();
		nesNoiseRegister = 0x0001;
		nesNoiseCounter = nesNoisePeriods[nesNoisePresetPitchIndex];//nesNoisePeriod;
		samplingFrequency = AudioSettings.outputSampleRate;
		
		Debug.Log("Output Sample Rate: " + AudioSettings.outputSampleRate);

		int bufferLength, numBuffers;
		AudioSettings.GetDSPBufferSize(out bufferLength, out numBuffers);
		Debug.Log("Buffer Length: " + bufferLength);
		Debug.Log("Buffer Count: " + numBuffers);

		AudioConfiguration config = AudioSettings.GetConfiguration();
		Debug.Log("Sample Rate: " + config.sampleRate);
		Debug.Log("Speaker Mode: " + config.speakerMode);
		Debug.Log("DSP Buffer Size: " + config.dspBufferSize);
		Debug.Log("Num Real Voices: " + config.numRealVoices);
		Debug.Log("Num Virtual Voices: " + config.numVirtualVoices);
		
	}

	void Start() {
		samplingFrequency = AudioSettings.outputSampleRate;

		frequencies = new float[8];
		frequencies[0] = 440;
		frequencies[1] = 494;
		frequencies[2] = 554;
		frequencies[3] = 587;
		frequencies[4] = 659;
		frequencies[5] = 740;
		frequencies[6] = 831;
		frequencies[7] = 880;

		float apuClock = 1789773 / 2;
		float scaler = AudioSettings.GetConfiguration().dspBufferSize / samplingFrequency;
		scaler = 1/440f;
		nesNoisePeriodsAdjusted = new int[16];
		for(int i = 0; i < nesNoisePeriods.Length; i++) {
			float adjustedClockSpeed = (apuClock / nesNoisePeriods[i]) * scaler;
			nesNoisePeriodsAdjusted[i] = (int)adjustedClockSpeed;
		}


	}

	void Update() {
		gain = volume;

		samplingFreqencyInstance = samplingFrequency;

		if(playSoundFromInput && Input.GetKeyDown(KeyCode.Space)) {
			if (playAScale) {
				frequency = frequencies[currentFreq];
				currentFreq = (currentFreq + 1) % frequencies.Length;
			}
		}

		if(playSoundFromInput && Input.GetKeyDown(KeyCode.Space)) {
			//gain = volume;
			if(volumeEnvelope != null && volumeEnvelope.envelopeEnabled)
				volumeEnvelope.SetGate(true);
			if(pitchEnvelope != null && pitchEnvelope.envelopeEnabled)
				pitchEnvelope.SetGate(true);
		}
		else if(playSoundFromInput && Input.GetKeyUp(KeyCode.Space)) {
			//gain = 0;
			if(volumeEnvelope != null && volumeEnvelope.envelopeEnabled)
				volumeEnvelope.SetGate(false);
			if(pitchEnvelope != null && pitchEnvelope.envelopeEnabled)
				pitchEnvelope.SetGate(false);
		}

		if(Input.GetKeyDown(KeyCode.Q)) {
			StartCoroutine(quickToggleNesNoiseMode());
		}

		for(int i = 0; i < 16; i++) {
			testNoiseReg[i] = IsBitSet(nesNoiseRegister, i);
		}
	}

	public IEnumerator quickToggleNesNoiseMode() {
		nesNoiseMode = !nesNoiseMode;
		yield return new WaitForEndOfFrame();
		yield return new WaitForEndOfFrame();
		//yield return new WaitForEndOfFrame();
		nesNoiseMode = !nesNoiseMode;
	}
	
	/********************************************************************************
	In an audio update, a chunk of audio is sent to the audio filter for playback. 
	This chunk is defined as an array of 1024 floats to describe the waveform.
	Update rate is <buffer size> / <sampling frequency>.
	On this Windows computer: 1024/48000 = 0.213... -> About 21.3 ms Update Time.
	This loop sets the floats in the buffer for this particular chunk of audio.
		
	Note: Phase is normalized to the interval [0f, 1f]
	This represents a period at the given frequency.
	This means you must convert the phase according to range you need.
	Ex: [0,1] -> [0, Pi^2] for sine wave
	********************************************************************************/
	void OnAudioFilterRead(float[] data, int channels) {
		//How far to move on x-axis of waveform each step of audio update
		increment = frequency / samplingFrequency;

		//Adjust speed according to pitch envelope
		if(pitchEnvelope != null && pitchEnvelope.envelopeEnabled)
			increment *= pitchEnvelope.GetOutput();

		for ( int i = 0; i < data.Length; i += channels ) {

			nesNoiseWaitCount--;

			#region Set phase (x-axis)
			//Adjust increment amount according to pitch envelope
			if (pitchEnvelope != null && pitchEnvelope.envelopeEnabled) {
				pitchEnvelope.Process();
				phase += increment * pitchEnvelope.GetOutput();
			}
			else {
				phase += increment;
			}
			#endregion

			#region Set volume of waveform (y-axis)
			double waveFormAmplitude;

			//Noise works differently to the other tones. Need special cases for those.
			if(waveForm == WaveForm.Noise)
				waveFormAmplitude = WhiteNoise(phase);
			else if(waveForm == WaveForm.NESNoise) {
				waveFormAmplitude = NESNoise();
			}
			else
				waveFormAmplitude = GetWaveFormAmplitude(waveForm, phase);
			data[i] = (float)(waveFormAmplitude * gain);

			//Adjust volume with volume envelope
			if (volumeEnvelope != null && volumeEnvelope.envelopeEnabled) {
				volumeEnvelope.Process();
				data[i] *= volumeEnvelope.GetOutput();
			}
			#endregion

			//Play sound out of 2nd speaker
			if (channels == 2)
				data[i + 1] = data[i];

			//Reset phase when it makes a full revolution
			if( phase >= 1f ) {
				phase = 0f;
				//nesNoiseGotSampleForThisPeriod = false;
			}
		}
	}

	public double GetWaveFormAmplitude (WaveForm waveForm, double phase) {
		switch (waveForm) {
			case WaveForm.Sine:
				return SineWave(sineType, phase);

			case WaveForm.Square:
				return ( (phase >= PulseWidth) ? 1f : -1f ) * squareWaveScale;

			case WaveForm.Triangle:
				return ( 1.0d - Math.Abs(( (2.0d * phase) - 1.0d) * 2) );

			case WaveForm.Sawtooth:
				return ( (2.0d * phase) - 1.0d ) * ( reverseSawtooth ? -1 : 1 );

			case WaveForm.Noise:
				return WhiteNoise(phase);

			case WaveForm.NESTriangle:
				return NesTriangle(phase);

			case WaveForm.NESNoise:
				return NESNoise();

			case WaveForm.LogSaw:
				return Math.Pow( -(2d * phase - 1d), (logsawVoice * 2) + 1 );

			case WaveForm.Fourier:
				return Fourier(phase);

			default:
				return 0;
		}
	}

	public double SineWave(SineWaveType type, double phase) {
		switch(type) {
			case SineWaveType.Sine:
				return Math.Sin(phase * PI2);

			case SineWaveType.HalfSine:
				return Math.Max( Math.Sin(phase * PI2), 0f );

			case SineWaveType.AbsSine:
				return Math.Abs( Math.Sin(phase * PI2) );

			case SineWaveType.QuarterSine:
				bool quarterCancel = ((int)(phase / 0.25d)) % 2 == 0;
				return Math.Abs( Math.Sin(phase * PI2) ) * ( quarterCancel ? 1 : 0 );

			case SineWaveType.AlternatingSine:
				return Math.Sin(phase * PI2 * 2) * ( (phase <= 0.5d) ? 1 : 0 );

			case SineWaveType.CamelSine:
				return Math.Abs( Math.Sin(phase * PI2 * 2) ) * ( (phase <= 0.5f) ? 1 : 0 );

			default:
				return 0f;
		}
	}

	public double WhiteNoise(double phase) {
		if (whitenoisePeriodCounter-- > 0)
			return savedWhiteNoise;

		if(pitchEnvelope != null && pitchEnvelope.envelopeEnabled)
			whitenoisePeriodCounter = whitenoisePeriod + pitchEnvelope.GetOutput();
		else
			whitenoisePeriodCounter = whitenoisePeriod;

		savedWhiteNoise = ( 2.0f * noiseMaxAmp * GetRandomFloat()) - noiseMaxAmp;
		if (noiseSquarify)
			savedWhiteNoise = Mathf.Sign(savedWhiteNoise) * squareWaveScale;

		return savedWhiteNoise;
	}

	public double NesTriangle(double phase) {
		/**
		if(nesTriangleTimer <= 0) {
			nesTriangleTimer = nesTrianglePeriod;
			nesTriangleDutyIndex = (nesTriangleDutyIndex + 1) % 32;
		}
		else {
			nesTriangleTimer--;
		}

		return (nesTriangleTable[nesTriangleDutyIndex] + 1) / 16f;
		**/

		double triangleWave = 1.0d - Math.Abs(( (2.0d * phase) - 1) * 2);
		double QTriangle = Math.Round(triangleWave * nesTriangleStep) * (1f/nesTriangleStep);
		return QTriangle;
	}

	public double NESNoise() {
		/**
		//Increment Timer only every other cycle if desired
		//if(nesNoiseEveryOtherCycle && !nesNoiseOddCycle)
		//	return 0;

		//if(nesNoiseCounter-- > 0)
		//	return ( !IsBitSet(nesNoiseRegister, 0) ? 1 : 0 ) * nesNoiseScale;

		//16f / (1f / nesNoiseCounter)) { //
		//nesNoiseGotTone = true;
		// + pitchEnvelope.GetOutput();

		if(phase > nesPhaseCheck) {
			if(nesNoiseGotTone) {
				return nesNoiseGetOutputBit();
			}
		}
		nesNoiseCounter = nesNoisePeriods[nesNoisePresetPitchIndex];
		**/
		
		//if(nesNoiseGotSampleForThisPeriod)
		//	return nesNoiseGetOutputBit();

		if(nesNoiseWaitCount > 0)
			return nesNoiseGetOutputBit();

		nesNoiseWaitCount = nesNoisePeriodsAdjusted[nesNoisePresetPitchIndex];
		nesPerformFeedbackOnNoiseRegister();
		//nesNoiseGotSampleForThisPeriod = true;
		return nesNoiseGetOutputBit();

	}

	public double Fourier(double phase) {
		double amplitude = 0;
		float curHarmonic = 1;
		for (int i = 0; i < iterations; i++) {
			//Square Wave
			amplitude += (1f/curHarmonic) * Math.Sin(phase * PI2 * curHarmonic);

			curHarmonic += nextHarmonic;
		}

		return amplitude;
	}

	private void nesPerformFeedbackOnNoiseRegister() {
		//https://wiki.nesdev.com/w/index.php/APU_Noise
		//When the timer clocks the shift register, the following actions occur in order:

		//Feedback is calculated as the exclusive-OR of bit 0 and one other bit: bit 6 if Mode flag is set, otherwise bit 1.
		bool firstBit = IsBitSet(nesNoiseRegister, 0);
		bool secondBit = nesNoiseMode ? IsBitSet(nesNoiseRegister, 6) : IsBitSet(nesNoiseRegister, 1);
		nesFeedbackBit = (!firstBit && secondBit) || (firstBit && !secondBit);
		
		//The shift register is shifted right by one bit.
		nesNoiseRegister >>= 1;
		
		//Bit 15, the leftmost bit, is set to the feedback calculated earlier.
		nesNoiseRegister |= (ushort)( (1 << 14) * (nesFeedbackBit ? 1 : 0) );
	}
	private float nesNoiseGetOutputBit() {
		return ( !IsBitSet(nesNoiseRegister, 0) ? 1 : 0 ) * nesNoiseScale;
	}
	public static bool IsBitSet(ushort counter, int pos) {
		return (counter & (1 << pos)) != 0;
	}
	
	public static float GetRandomFloat() {
		//http://stackoverflow.com/questions/767999/random-number-generator-only-generating-one-random-number
		lock (syncLock) {	//Synchronize
			return (float)random.NextDouble();
		}
	}
}
