﻿using UnityEngine;
using System.Collections;

public class WaveFormVisualizer : MonoBehaviour {
	public float gain = 10;
	public float phase = 0;
	public float phaseSpeed = 5f;
	public float phaseScale = 5;
	private const float PI2 = Mathf.PI * 2;

	[Range(0, 1f)]
	public float pulseWidth = 0.5f;
	public float PulseWidth {
		get { return pulseWidth; }
	}

	public Oscillator oscillator;
	public int cycleCount = 2;

	void Update() {
		phase = (phase + Time.deltaTime * phaseSpeed) % cycleCount; 

		transform.localPosition = new Vector3(
			phase * phaseScale,
			gain * (float)oscillator.GetWaveFormAmplitude(oscillator.waveForm, phase),
			0);
	}

}