﻿using UnityEngine;
using System.Collections;
using System;

/************************
	Notes: ADSR
	Attack		Rate from 0% to 100% Amplitude
	Decay		Rate from 100% to Sustain Level
	Sustain		A level to be held while key is pressed (Note: This is not time, but an amplitude level.)
	Release		After key released, Rate from Sustain Level to 0%
************************/
[System.Serializable]
public class Envelope : MonoBehaviour {
	public enum State { Idle, Attack, Decay, Sustain, Release }
	private const float epsilon = 0.000001f;

	protected State envState = State.Attack;
	protected float output = 0f;

	//Attack
	protected float attackRate;
	protected float attackCoef;
	protected float attackBase;
	protected float targetRatioA;

	//Decay
	protected float decayRate;
	protected float decayCoef;
	protected float decayBase;
	protected float targetRatioDR;

	//Sustain
	protected float sustainLevel;

	//Release
	protected float releaseRate;
	protected float releaseCoef;
	protected float releaseBase;

	//Enabled
	public bool envelopeEnabled = true;

	//Output Scale
	public float minOutputScale = 0f;
	public float maxOutputScale = 1f;

	//Initializers
	public float attackRateView = 0;
	public float decayRateView = 0;
	public float releaseRateView = 0;
	[Range (0f, 1f)]
	public float sustainLevelView = 1.0f;
	public float targetRatioAView = 0.3f;
	public float targetRatioDRView = 0.0001f;

	public float AttackRate {
		get { return attackRateView; }
		set { value = attackRateView; SetAttackRate(attackRateView * Oscillator.samplingFrequency); }
	}
	public float DecayRate {
		get { return decayRateView; }
		set { value = decayRateView; SetDecayRate(decayRateView * Oscillator.samplingFrequency); }
	}
	public float SustainLevel {
		get  { return sustainLevelView; }
		set { value = sustainLevelView; SetSustainLevel(sustainLevelView); }
	}
	public float ReleaseRate {
		get { return releaseRateView; }
		set { value = releaseRateView; SetReleaseRate(releaseRateView * Oscillator.samplingFrequency); }
	}
	public float TargetRatioA {
		get { return targetRatioAView; }
		set { value = targetRatioAView; SetTargetRatioA(targetRatioAView); }
	}
	public float TargetRatioDR {
		get { return targetRatioDRView; }
		set { value = targetRatioDRView; SetTargetRatioDR(targetRatioDRView); }
	}

	void Awake() {
		Initialize();
	}

	void OnValidate() {
		Initialize();
	}

	public void InitializeASDROnly() {
		SustainLevel = sustainLevelView;
		TargetRatioA = targetRatioAView;
		TargetRatioDR = targetRatioDRView;
		AttackRate = attackRateView;
		DecayRate = decayRateView;
		ReleaseRate = releaseRateView;
	}

	public void Initialize() {
		Reset();
		InitializeASDROnly();
	}


	public float Process() {
		switch(envState) {
			case State.Idle:
				//Do nothing.
				break;

			case State.Attack:
				output = attackBase + output * attackCoef;
				if(output >= 1f) {
					output = 1f;
					envState = State.Decay;
				}
				break;

			case State.Decay:
				output = decayBase + output * decayCoef;
				if(output <= sustainLevel) {
					output = sustainLevel;
					envState = State.Sustain;
				}
				break;

			case State.Sustain:
				//Do nothing.
				break;

			case State.Release:
				output = releaseBase + output * releaseCoef;
				if(output <= 0f) {
					output = 0f;
					envState = State.Idle;
				}
				break;
		}
		return output;
	}
	public float GetOutput() {
		return Mathf.Lerp(minOutputScale, maxOutputScale, output);
	}
	public float GetNormalizedOutput() {
		return output;
	}

	public void Reset() {
		envState = State.Idle;
		output = 0f;
	}
	public void SetGate(bool gate) {
		if(gate)
			envState = State.Attack;
		else
			envState = State.Release;
	}
	public float GetExponentialCoef(float rate, float targetRatio) {
		return Mathf.Exp( -Mathf.Log( (1.0f + targetRatio) / targetRatio ) / rate);
	}

	//Rates
	public void SetAttackRate(float rate) {
		attackRate = rate;
		attackCoef = GetExponentialCoef( rate, targetRatioA );
		attackBase = ( 1.0f + targetRatioA ) * ( 1.0f - attackCoef );
	}
	public void SetDecayRate(float rate) {
		decayRate = rate;
		decayCoef = GetExponentialCoef( rate, targetRatioDR );
		decayBase = ( sustainLevel - targetRatioDR ) * ( 1.0f - decayCoef );
	}
	public void SetReleaseRate(float rate) {
		releaseRate = rate;
		releaseCoef = GetExponentialCoef( rate, targetRatioDR );
		releaseBase = -targetRatioDR * ( 1.0f - releaseCoef );
	}
	public void SetSustainLevel(float level) {
		sustainLevel = Mathf.Clamp01( level );
		decayBase = ( sustainLevel - targetRatioDR ) * ( 1.0f - decayCoef );
	}

	//Target Ratios
	public void SetTargetRatioA (float targetRatio) {
		if( targetRatio < epsilon )
			targetRatio = epsilon;
		targetRatioA = targetRatio;
		attackCoef = GetExponentialCoef( attackRate, targetRatioA );
		attackBase = ( 1.0f - targetRatioA ) * ( 1.0f - attackCoef );
	}
	public void SetTargetRatioDR(float targetRatio) {
		if( targetRatio < epsilon )
			targetRatio = epsilon;
		targetRatioDR = targetRatio;
		decayCoef = GetExponentialCoef( decayRate, targetRatioDR );
		releaseCoef = GetExponentialCoef( releaseRate, targetRatioDR );
		decayBase = ( sustainLevel - targetRatioDR ) * ( 1.0f - decayCoef );
		releaseBase = -targetRatioDR * ( 1.0f - releaseCoef );
	}
}
