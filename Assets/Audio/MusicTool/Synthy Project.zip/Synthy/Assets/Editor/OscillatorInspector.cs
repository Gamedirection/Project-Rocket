﻿using UnityEngine;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(Oscillator))]
public class OscillatorInspector : Editor {

	public override void OnInspectorGUI() {
		//base.OnInspectorGUI();

		Oscillator oscillator = (Oscillator)target;

		//General
		EditorGUILayout.Space();
		EditorGUILayout.LabelField("General Options");
		EditorGUILayout.BeginVertical("Box");
		oscillator.waveForm = (WaveForm)EditorGUILayout.EnumPopup("Wave Form", oscillator.waveForm);
		EditorGUILayout.LabelField("Gain", oscillator.gain.ToString("F2"));
		oscillator.volume = EditorGUILayout.FloatField("Volume", oscillator.volume);

		EditorGUILayout.BeginHorizontal();
		if( GUILayout.Button( (!oscillator.playSoundFromInput ? "Enable" : "Disable") + " User Input") )
			oscillator.playSoundFromInput = !oscillator.playSoundFromInput;
		
		if(CanPlayScales(oscillator) && GUILayout.Button( (!oscillator.playAScale ? "Enable" : "Disable") + " Test A-Scales") )
			oscillator.playAScale = !oscillator.playAScale;
		EditorGUILayout.EndHorizontal();
		EditorGUILayout.EndVertical();

		//Wave Form Specific
		EditorGUILayout.Space();
		EditorGUILayout.LabelField("Wave Form Options");
		EditorGUILayout.BeginVertical("Box");
		WaveFormUI(oscillator);
		EditorGUILayout.EndVertical();

		//Envelopes
		EditorGUILayout.Space();
		EditorGUILayout.LabelField("Envelopes");
		EditorGUILayout.BeginVertical("Box");
		oscillator.volumeEnvelope = (Envelope)EditorGUILayout.ObjectField("Volume Envelope", oscillator.volumeEnvelope, typeof(Envelope), true);
		oscillator.pitchEnvelope = (Envelope)EditorGUILayout.ObjectField("Pitch Envelope", oscillator.pitchEnvelope, typeof(Envelope), true);
		EditorGUILayout.EndVertical();
	}

	bool CanPlayScales(Oscillator oscillator) {
		return !(
			oscillator.waveForm == WaveForm.Noise ||
			oscillator.waveForm == WaveForm.NESNoise);
	}

	void WaveFormUI(Oscillator oscillator) {
		switch(oscillator.waveForm) {
			case WaveForm.Sine:
				SineUI(oscillator);
				break;

			case WaveForm.Square:
				SquareUI(oscillator);
				break;

			case WaveForm.Triangle:
				TriangleUI(oscillator);
				break;

			case WaveForm.Sawtooth:
				SawtoothUI(oscillator);
				break;

			case WaveForm.Noise:
				NoiseUI(oscillator);
				break;

			case WaveForm.NESTriangle:
				NESTriangleUI(oscillator);
				break;

			case WaveForm.NESNoise:
				NESNoiseUI(oscillator);
				break;

			case WaveForm.LogSaw:
				LogSawUI(oscillator);
				break;

			case WaveForm.Fourier:
				FourierUI(oscillator);
				break;

			default:
				MissingUI();
				break;
		}
	}
	void Frequency(Oscillator oscillator) {
		oscillator.frequency = System.Math.Max( EditorGUILayout.FloatField("Frequency", oscillator.frequency), 0.0f );
	}
	void SineUI(Oscillator oscillator) {
		oscillator.sineType = (SineWaveType)EditorGUILayout.EnumPopup("Sine Wave Type", oscillator.sineType);
		Frequency(oscillator);
	}
	void SquareUI(Oscillator oscillator) {
		Frequency(oscillator);
		oscillator.userPulseWidth = EditorGUILayout.Slider("Pulse Width Ratio", oscillator.userPulseWidth, 0f, 1f);
		oscillator.squareWaveScale = EditorGUILayout.Slider("Square Wave Scale", oscillator.squareWaveScale, 0f, 1f);
	}
	void TriangleUI(Oscillator oscillator) {
		Frequency(oscillator);
	}
	void SawtoothUI(Oscillator oscillator) {
		if( GUILayout.Button( (oscillator.reverseSawtooth ? "Reverse Sawtooth" : "Sawtooth") ) )
			oscillator.reverseSawtooth = !oscillator.reverseSawtooth;
		Frequency(oscillator);
	}
	void NESTriangleUI(Oscillator oscillator) {
		Frequency(oscillator);
		oscillator.nesTriangleStep = Mathf.Max( EditorGUILayout.IntField("Quantization Steps", oscillator.nesTriangleStep), 1);
	}
	void NoiseUI(Oscillator oscillator) {
		if( GUILayout.Button( (!oscillator.noiseSquarify ? "White Noise" : "Squarified Noise") ) )
			oscillator.noiseSquarify = !oscillator.noiseSquarify;
		oscillator.whitenoisePeriod = Mathf.Max( EditorGUILayout.FloatField("Noise Period", oscillator.whitenoisePeriod), 0 );
		oscillator.noiseMaxAmp = EditorGUILayout.FloatField("Noise Amplitude Scale", oscillator.noiseMaxAmp);
		if(oscillator.noiseSquarify)
			oscillator.squareWaveScale = EditorGUILayout.Slider("Square Wave Scale", oscillator.squareWaveScale, 0f, 1f);
	}
	void NESNoiseUI(Oscillator oscillator) {
		EditorGUILayout.BeginHorizontal();
		if( GUILayout.Button( (!oscillator.nesNoiseMode ? "NES Noise Mode 1" : "NES Noise Mode 2") ) )
			oscillator.nesNoiseMode = !oscillator.nesNoiseMode;
		//if( GUILayout.Button( (!oscillator.nesNoiseEveryOtherCycle ? "Every Cycle" : "Every Other Cycle") ) )
		//	oscillator.nesNoiseEveryOtherCycle = !oscillator.nesNoiseEveryOtherCycle;
		EditorGUILayout.EndHorizontal();

		//oscillator.nesNoisePeriod = Mathf.Max( EditorGUILayout.IntField("NES Noise Period", oscillator.nesNoisePeriod), 0);

		oscillator.nesNoisePresetPitchIndex = Mathf.Clamp( EditorGUILayout.IntSlider("Noise Pitch Type", oscillator.nesNoisePresetPitchIndex, 0, 15), 0, 15);
		EditorGUILayout.LabelField("Noise Frequency", oscillator.nesNoisePeriodsAdjusted[oscillator.nesNoisePresetPitchIndex].ToString());
		//oscillator.frequency = oscillator.nesNoisePeriods[ oscillator.nesNoisePresetPitchIndex ];
		//Frequency(oscillator);
		//oscillator.frequency = EditorGUILayout.Slider("Noise Frequency", oscillator.frequency, 0, oscillator.samplingFreqencyInstance);
		//EditorGUILayout.LabelField("Frequency", oscillator.frequency.ToString());
		
		//oscillator.nesPhaseCheck = EditorGUILayout.Slider("Noise Pitch", oscillator.nesPhaseCheck, 0f, 1f);
		//oscillator.nesNoisePresetPitchIndex = EditorGUILayout.IntSlider("Noise Pitch Type", oscillator.nesNoisePresetPitchIndex, 0, 15);
		oscillator.nesNoiseScale = EditorGUILayout.Slider("Noise Scale", oscillator.nesNoiseScale, 0f, 1f);
	}
	void LogSawUI(Oscillator oscillator) {
		Frequency(oscillator);
		oscillator.logsawVoice = Mathf.Max( EditorGUILayout.IntField("Voice", oscillator.logsawVoice), 0 );
	}
	void FourierUI(Oscillator oscillator) {
		Frequency(oscillator);
		oscillator.iterations = System.Math.Max( EditorGUILayout.IntSlider("Iterations", oscillator.iterations, 1, 16), 0 );
		oscillator.nextHarmonic = EditorGUILayout.FloatField("Next Harmonic Iteration", oscillator.nextHarmonic);
	}
	void MissingUI() {
		EditorGUILayout.LabelField("No Valid Waveform Selected.");
	}
}
