﻿using UnityEngine;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(Envelope))]
public class EnvelopeInspector : Editor {

	public override void OnInspectorGUI() {
	
		base.OnInspectorGUI();

		Envelope env = (Envelope)target;

		EditorGUILayout.BeginHorizontal();
		EditorGUILayout.LabelField("Normal Output", env.GetNormalizedOutput().ToString("F2"));
		EditorGUILayout.Slider(env.GetNormalizedOutput(), 0f, 1f);
		EditorGUILayout.EndHorizontal();

		EditorGUILayout.LabelField("Scaled Output", env.GetOutput().ToString("F2"));
		EditorGUILayout.LabelField("Random", Random.value.ToString("F2"));
		/**
		Envelope env = (Envelope)target;

		//Attack
		env.AttackRate = EditorGUILayout.FloatField("Attack Rate", Mathf.Max( env.AttackRate, 0f) );
		//Decay
		env.DecayRate = EditorGUILayout.FloatField("Decay Rate", Mathf.Max( env.DecayRate, 0f ));
		//Sustain
		env.SustainLevel = EditorGUILayout.Slider("Sustain Level", Mathf.Clamp01( env.DecayRate ), 0f, 1f);
		//Release
		env.DecayRate = EditorGUILayout.FloatField("Release Rate", Mathf.Max( env.ReleaseRate, 0f ));
		//Target Ratio A
		env.TargetRatioA =  EditorGUILayout.FloatField("Target Ratio A", env.TargetRatioA);
		//Target Ratio DR
		env.TargetRatioDR =  EditorGUILayout.FloatField("Target Ratio DR", env.TargetRatioDR);
		*/
	}
}
