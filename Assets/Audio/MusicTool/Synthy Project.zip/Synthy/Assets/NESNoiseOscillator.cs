﻿using UnityEngine;
using System.Collections;

public class NESNoiseOscillator : MonoBehaviour {

	public float frequency = 440f;	//Frequency in Hz of tone that is played
	private float increment;		//Amount of distance incremented each frame according to frequency
	private float phase;			//Location on the wave

	public float gain = 0.1f;

	[Range (0, 15)]
	public int nesNoiseFrequency = 0;
	public float[] nesNoisePeriods = { 4, 8, 16, 32, 64, 96, 128, 160, 202, 254, 380, 508, 762, 1016, 2034, 4068 };	//https://wiki.nesdev.com/w/index.php/APU_Noise
	public bool nesNoiseMode = false;

	private ushort nesNoiseRegister = 1;

	public Envelope volumeEnvelope;
	public Envelope pitchEnvelope;

	public int incrementCounter = 0;

	void Awake() {
		float bufferSize = AudioSettings.GetConfiguration().dspBufferSize;
		for(int i = 0; i < nesNoisePeriods.Length; i++) {
			nesNoisePeriods[i] = ((nesNoisePeriods[i] / 1789773f) * Oscillator.samplingFrequency) / (bufferSize / Oscillator.samplingFrequency);
			nesNoisePeriods[i] /= 1;
		}
	}

	void Update() {
		if(Input.GetKeyDown(KeyCode.Space)) {
			//gain = volume;
			if(volumeEnvelope != null && volumeEnvelope.envelopeEnabled)
				volumeEnvelope.SetGate(true);
			if(pitchEnvelope != null && pitchEnvelope.envelopeEnabled)
				pitchEnvelope.SetGate(true);
		}
		else if(Input.GetKeyUp(KeyCode.Space)) {
			//gain = 0;
			if(volumeEnvelope != null && volumeEnvelope.envelopeEnabled)
				volumeEnvelope.SetGate(false);
			if(pitchEnvelope != null && pitchEnvelope.envelopeEnabled)
				pitchEnvelope.SetGate(false);
		}

		frequency = nesNoisePeriods[nesNoiseFrequency];
	}

	void OnAudioFilterRead(float[] data, int channels) {
		//How far to move on x-axis of waveform each step of audio update
		increment = 1 / Oscillator.samplingFrequency;

		//Adjust speed according to pitch envelope
		if(pitchEnvelope != null && pitchEnvelope.envelopeEnabled)
			increment *= pitchEnvelope.GetOutput();

		for ( int i = 0; i < data.Length; i += channels ) {

			#region Set phase (x-axis)
			//Adjust increment amount according to pitch envelope
			if (pitchEnvelope != null && pitchEnvelope.envelopeEnabled) {
				pitchEnvelope.Process();
				phase += increment * pitchEnvelope.GetOutput();
			}
			else {
				phase += increment;
			}
			#endregion

			#region Set volume of waveform (y-axis)
			double waveFormAmplitude = NESNoise();
			data[i] = (float)(waveFormAmplitude * gain);

			//Adjust volume with volume envelope
			if (volumeEnvelope != null && volumeEnvelope.envelopeEnabled) {
				volumeEnvelope.Process();
				data[i] *= volumeEnvelope.GetOutput();
			}
			#endregion

			//Play sound out of 2nd speaker
			if (channels == 2)
				data[i + 1] = data[i];

			//Reset phase when it makes a full revolution
			incrementCounter++;
			if( phase >= 1f ) {
				phase = 0f;
				//nesNoiseGotSampleForThisPeriod = false;
			}
		}
	}

	public double NESNoise() {
		if(incrementCounter < nesNoisePeriods[nesNoiseFrequency]) {
			return nesNoiseGetOutputBit();
		}

		incrementCounter = 0;
		nesPerformFeedbackOnNoiseRegister();
		return nesNoiseGetOutputBit();
	}

	private void nesPerformFeedbackOnNoiseRegister() {
		//https://wiki.nesdev.com/w/index.php/APU_Noise
		//When the timer clocks the shift register, the following actions occur in order:

		//Feedback is calculated as the exclusive-OR of bit 0 and one other bit: bit 6 if Mode flag is set, otherwise bit 1.
		bool firstBit = IsBitSet(nesNoiseRegister, 0);
		bool secondBit = nesNoiseMode ? IsBitSet(nesNoiseRegister, 6) : IsBitSet(nesNoiseRegister, 1);
		bool nesFeedbackBit = (!firstBit && secondBit) || (firstBit && !secondBit);
		
		//The shift register is shifted right by one bit.
		nesNoiseRegister >>= 1;
		
		//Bit 15, the leftmost bit, is set to the feedback calculated earlier.
		nesNoiseRegister |= (ushort)( (1 << 14) * (nesFeedbackBit ? 1 : 0) );
	}
	private float nesNoiseGetOutputBit() {
		return ( !IsBitSet(nesNoiseRegister, 0) ? 1 : 0 );
	}
	public static bool IsBitSet(ushort counter, int pos) {
		return (counter & (1 << pos)) != 0;
	}

}
